{
    'name': 'Owl Demo',
    'summary': 'Owl Demo',
    'depends': ['base', 'portal', 'crm'],
    'data': [
        'views/templates.xml'
    ],
    'installable': True,
    'application': True,
}
