{
    'name': 'Owl Demo',
    'summary': 'Owl Demo',
    'depends': ['base', 'portal'],
    'data': [
        'views/templates.xml',
    ],
    'installable': True,
    'application': True,
}
